const { MessageEmbed } = require("discord.js");

module.exports = (client) => {
    client.on("guildMemberAdd", async member => {
        member.send(new MessageEmbed()
            .setDescription(`Witaj ${member.user.username}, \nWłaśnie dołączyłeś/aś na Discorda serwera BlackMTA\n\n🔰 Zapoznaj się z regulaminem serwera MTA/Discord \n📰 Regulamin znajdziesz na kanale #📰┇regulamin\n❓ Jeżeli masz jakieś pytania odnośnie serwera napisz wiadomość do naszej Administracji\n🕹️ Życzymy miłej gry!`)
            .setColor("GREEN")
        )
    })
}