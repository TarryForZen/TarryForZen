from discord.ext import commands
import discord


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="serverinfo", aliases=["profilguild"])
    async def serverinfo(self, ctx):

        embed = discord.Embed(
            title="Informacje o Serwerze",
            color=discord.Colour.green()
        )

        fields = [
            ("Nazwa", str(ctx.guild.name)),
            ("ID", str(ctx.guild.id)),
            ("Region", str(ctx.guild.region).title()),
            ("Właściciel", ctx.guild.owner),
            ("Członkowie", ctx.guild.member_count),
            ("Utworzono", ctx.guild.created_at.strftime("%d.%m.%Y %H:%M")),
            ("Role", len(ctx.guild.roles)),
            ("Kanały", len(ctx.guild.text_channels + ctx.guild.voice_channels)),
            ("Ikona", f"[Kliknij]({ctx.guild.icon_url})")
        ]

        for name, value in fields:
            embed.add_field(name=name, value=value)

        embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
        await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Admin(bot))