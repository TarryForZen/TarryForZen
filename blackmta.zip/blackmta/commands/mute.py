@client.command(description="Wycisza określonego użytkownika..")
@commands.has_permissions(manage_messages=True)
async def mute(ctx, member: discord.Member, *, reason=None):
    guild = ctx.guild
    mutedRole = discord.utils.get(guild.roles, name="Wyciszony")

    if not mutedRole:
        mutedRole = await guild.create_role(name="Wyciszony")

        for channel in guild.channels:
            await channel.set_permissions(mutedRole, speak=False, send_messages=False, read_message_history=True, read_messages=False)
    embed = discord.Embed(title="Wyciszony", description=f"{member.mention} został wyciszony ", colour=discord.Colour.light_gray())
    embed.add_field(name="Powód:", value=reason, inline=False)
    await ctx.send(embed=embed)
    await member.add_roles(mutedRole, reason=reason)
    await member.send(f"Zostałeś wyciszony na serwerze: {guild.name} Powód: {reason}")