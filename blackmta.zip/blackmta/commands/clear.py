from discord.ext import commands
import discord


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="clear", aliases=["purge"])
    async def clear(self, ctx, msgNum: int = 1):
        if not ctx.author.guild_permissions.manage_messages:

            embed = discord.Embed(
                title="Błąd",
                description="Nie możesz usunąć wiadomości ponieważ nie posiadasz uprawnień `Zarządzanie wiadomościami`",
                color=discord.Colour.red()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)
        else:
            if msgNum > 99:

                embed = discord.Embed(
                    title="Błąd",
                    description="Ze względu na wydajność bota, nie możesz usunąć więcej niż `99` wiadomości naraz",
                    color=discord.Colour.red()
                )

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed, mention_author=False)
            else:
                await ctx.channel.purge(limit=msgNum + 1)
                await ctx.channel.send(f"Usunięto **{msgNum}** wiadomości przez {ctx.author.mention}", delete_after=1)

    @commands.command(name="resetchannel", aliases=["clear*"])
    async def resetchannel(self, ctx):
        if not ctx.author.guild_permissions.manage_messages:

            embed = discord.Embed(
                title="Błąd",
                description="Nie możesz usunąć wiadomości ponieważ nie posiadasz uprawnień `Zarządzanie wiadomościami`",
                color=discord.Colour.red()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)
        else:
            channel_clone = await ctx.channel.clone()
            await ctx.channel.delete()
            await channel_clone.send(f"Zresetowano kanał `{ctx.channel.name}` przez {ctx.author.mention}", delete_after=2)


def setup(bot):
    bot.add_cog(Admin(bot))