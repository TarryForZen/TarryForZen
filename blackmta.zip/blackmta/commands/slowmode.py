from discord.ext import commands


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="slowmode", aliases=["cooldown"])
    async def slowmode(self, ctx, time: int = None):
        if not ctx.author.guild_permissions.manage_messages:
            await ctx.send("⛔ **Nie posiadasz uprawnień `Zarządzanie wiadomościami`**")
        elif time is None:
            await ctx.send("📴 **Wyłączono slowmode**")
            await ctx.channel.edit(slowmode_delay=0)
        else:
            if time <= 0:
                await ctx.send("📴 **Wyłączono slowmode**")
                await ctx.channel.edit(slowmode_delay=0)
            elif time > 21600:
                await ctx.send("🕕 **Slowmode nie może być większy niż 6 godzin**")
            else:
                await ctx.channel.send(f"✅ **Ustawiono slowmode na {time} sek.**")
                await ctx.channel.edit(slowmode_delay=time)


def setup(bot):
    bot.add_cog(Admin(bot))