
from discord.ext import commands
import discord


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="setnick", aliases=["nick", "changenick"])
    async def setnick(self, ctx, member: discord.Member = None, *, nick=None):
        if not ctx.author.guild_permissions.manage_nicknames:

            embed = discord.Embed(
                title="Błąd",
                description="Nie posiadasz uprawnień `Zarządzanie pseudonimami`",
                color=discord.Colour.red()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)
        else:
            if member is None or nick is None:

                embed = discord.Embed(
                    title="Błąd",
                    description="Nie podano użytkownika do zmiany jego pseudonimu bądź nowego pseudonimu jaki ma zostać ustawiony\nPoprawne użycie `k!nick <@użytkownik> <nowy pseudonim>`",
                    color=discord.Colour.red()
                )

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)
            else:
                await member.edit(nick=nick)

                embed = discord.Embed(
                    title="Pomyślnie zmieniono pseudonim",
                    description=f"{ctx.author.mention} zmienił nick użytkownika {member.mention} na `{nick}`",
                    color=discord.Colour.green()
                )

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Admin(bot))