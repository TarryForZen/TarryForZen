from discord.ext import commands
import discord


class Other(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="ankieta", aliases=["questionnaire", "pytanie"])
    async def ankieta(self, ctx, *, ankieta="Powinno podawać się treść ankiety?!"):

        embed = discord.Embed(
            title="Ankieta!",
            description=f">>> {ankieta}"
        )

        embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
        msg = await ctx.send(embed=embed)

        await msg.add_reaction("✅")
        await msg.add_reaction("❌")

        await ctx.message.delete()


def setup(bot):
    bot.add_cog(Other(bot))