@client.command()
async def tempmute(ctx, member: discord.Member, time: int, d, *, reason=None):
    guild = ctx.guild

    for role in guild.roles:
        if role.name == "Wyciszony":
            await member.add_roles(role)

            embed = discord.Embed(title="Wyciszony!", description=f"{member.mention} został wyciszony tymczasowo ", colour=discord.Colour.light_gray())
            embed.add_field(name=["powod]:", value=reason, inline=False)
            embed.add_field(name="czas pozostały do ​​wyciszenia:", value=f"{time}{d}", inline=False)
            await ctx.send(embed=embed)

            if d == "s":
                await asyncio.sleep(time)

            if d == "m":
                await asyncio.sleep(time*60)

            if d == "h":
                await asyncio.sleep(time*60*60)

            if d == "d":
                await asyncio.sleep(time*60*60*24)

            await member.remove_roles(role)

            embed = discord.Embed(title="unmute (temp) ", description=f"unmuted -{member.mention} ", colour=discord.Colour.light_gray())
            await ctx.send(embed=embed)

            return
