from discord.ext import commands
import discord


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="userinfo", aliases=["profil"])
    async def userinfo(self, ctx, member: discord.Member = None):
        if member is None:
            member = ctx.author

        embed = discord.Embed(
            title="Informacje o Użytkowniku",
            color=discord.Colour.green()
        )

        fields = [
            ("Nazwa", str(member)),
            ("ID", member.id),
            ("Bot", member.bot),
            ("Najwyższa ranga", member.top_role.mention),
            ("Status", str(member.status).title()),
            ("Stworzono", member.created_at.strftime("%d.%m.%Y %H:%M")),
            ("Dołączono", member.joined_at.strftime("%d.%m.%y %H:%M")),
            ("Booster", bool(member.premium_since)),
            ("Avatar", f"[Kliknij]({member.avatar_url})")
        ]

        for name, value in fields:
            embed.add_field(name=name, value=value)

        embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
        await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Admin(bot))