from discord.ext import commands
import discord
import random


class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="ship")
    async def ship(self, ctx, member1: discord.Member = None, member2: discord.Member = None):
        if member1 is None or member2 is None:

            embed = discord.Embed(
                title="Błąd",
                description="Nie oznaczyłeś(-aś) dwóch osób",
                color=discord.Colour.red()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)
        else:
            ship_rnd = random.randint(0, 100)

            embed = discord.Embed(
                title="Ship...",
                description=f"{member1.mention} + {member2.mention} = **{ship_rnd}%**",
                color=discord.Colour.purple()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Fun(bot))