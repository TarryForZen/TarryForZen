from discord.ext import commands
import discord
import platform


class Bot(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # bot.remove_command("pomoc")

    # @commands.command(name="pomoc", aliases=["cmd", "cmds", "command", "commands"])
    # async def help(self, ctx):
    #     embed = discord.Embed(title="BlackMTA 0.1", description=f"""
    #     **Administracyjne:**
    #     ```addrole, ban, clear, kick, serverinfo, setnick, slowmode, unban, userinfo```
    #     **Bot:**
    #     ```botinfo, pomoc, ping,```
    #     **Fun:**
    #     ```binary, iq, mem, ship,```
    #     **Inne:**
    #     ```ankieta, avatar, embed```
    #     """, color=discord.Colour.green())
    #     embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
    #     await ctx.reply(embed=embed)

    @commands.command(name="botinfo", aliases=["bot"])
    async def botinfo(self, ctx):
        embed = discord.Embed(title="Informacje o Bocie", color=discord.Colour.green())

        fields = [
            ("Wersja Python", platform.python_version()),
            ("Wersja Discord.PY", discord.__version__),
            ("Właściciel", "<@881243055238287410>"),
            ("Ping bota", round(self.bot.latency * 1000))
        ]

        for name, value in fields:
            embed.add_field(name=name, value=value)

        embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)

        await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Bot(bot))