from discord.ext import commands
import discord


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="addrole", aliases=["add_role", "ar"])
    async def addrole(self, ctx, member: discord.Member = None, role: discord.Role = None):
        if not ctx.author.guild_permissions.manage_roles:

            embed = discord.Embed(
                title="Błąd",
                description="Nie posiadasz uprawnień `Zarządzanie rolami`",
                color=discord.Colour.red()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)
        else:
            if member is None or role is None:

                embed = discord.Embed(
                    title="Błąd",
                    description="Nie podano użytkownika, bądź roli do nadania!\nPoprawne użycie `k!addrole <@użytkownik> <@rola>`",
                    color=discord.Colour.red()
                )

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)
            else:
                await member.add_roles(role)
                await ctx.reply("📌 **Pomyślnie nadano role**")


def setup(bot):
    bot.add_cog(Admin(bot))