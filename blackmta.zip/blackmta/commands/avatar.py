from discord.ext import commands
import discord


class Other(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="avatar", aliases=["av"])
    async def avatar(self, ctx, member: discord.Member = None):
        if member is None:
            member = ctx.author

        embed = discord.Embed(
            title="Avatar Użytkownika",
            description=f"[{member.name}]({member.avatar_url})",
            color=discord.Colour.green()
        )

        embed.set_image(url=member.avatar_url)
        embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
        await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Other(bot))