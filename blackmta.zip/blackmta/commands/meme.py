from discord.ext import commands
import aiohttp
import discord


class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="mem", aliases=["meme"])
    async def mem(self, ctx):
        async with aiohttp.ClientSession() as cs:
            async with cs.get("https://api.luxbot.ml/memy") as r:
                data = await r.json()

                embed = discord.Embed(
                    title="Oto Twój jakże śmieszny mem!",
                    color=discord.Colour.green()
                )

                embed.set_image(url=data['mem'])
                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Fun(bot))