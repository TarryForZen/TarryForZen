from discord.ext import commands
import discord


class Bot(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="ping", aliases=["opoznienie"])
    async def ping(self, ctx):

        embed = discord.Embed(
            title="PONG! :ping_pong: ",
            description=str(round(self.bot.latency * 1000)) + " ms",
            color=discord.Colour.green()
        )

        embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
        await ctx.send(embed=embed)


def setup(bot):
    bot.add_cog(Bot(bot))