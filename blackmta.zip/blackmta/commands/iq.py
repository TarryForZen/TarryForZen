from discord.ext import commands
import discord
import random


class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="iq", aliases=["mojeiq", "oblicziq"])
    async def iq(self, ctx, member: discord.Member = None):
        if member is None:
            member = ctx.author

        iq = random.randint(10, 250)

        embed = discord.Embed(
            title="Kalkulator IQ",
            description=f"Poziom inteligencji użytkownika {member.mention} wynosi **{iq}** iq",
            color=discord.Colour.blue()
        )

        embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
        await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Fun(bot))