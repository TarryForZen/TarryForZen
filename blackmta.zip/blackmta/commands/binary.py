from discord.ext import commands
import aiohttp
import discord


class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="binary", aliases=["bin"])
    async def binary(self, ctx, *, text: str = None):
        if text is None:

            embed = discord.Embed(
                title="Błąd",
                description="Nie podano tekstu do zakodowania!\nPoprawne użycie `k!binary <text>`",
                color=discord.Colour.red())

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)
        else:
            async with aiohttp.ClientSession() as cs:
                async with cs.get(f"https://some-random-api.ml/binary?text={text}") as r:
                    data = await r.json()

                    embed = discord.Embed(
                        title="Binary Code",
                        description=f"**Text: `{text}`**\n**Binary: `{data['binary']}`**",
                        color=discord.Colour.green()
                    )

                    embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                    await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Fun(bot))