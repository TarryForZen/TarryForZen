@client.command(description="Anuluje wyciszenie określonego użytkownika.")
@commands.has_permissions(manage_messages=True)
async def unmute(ctx, member: discord.Member):
   mutedRole = discord.utils.get(ctx.guild.roles, name="Wyciszony")

   await member.remove_roles(mutedRole)
   await member.send(f" Mute został ci zdjęty przez administratora - {ctx.guild.name}")
   embed = discord.Embed(title="unmute", description=f" unmuted-{member.mention}",colour=discord.Colour.light_gray())
   await ctx.send(embed=embed)