from discord.ext import commands
import discord


class Other(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="embed", aliases=[])
    async def embed(self, ctx, *, args):
        args = args.split("|")
        color = int(hex(int(args[2].replace("#", ""), 16)), 0)
        embed = discord.Embed(title=args[0], description=args[1], color=color)
        await ctx.send(embed=embed)

    @embed.error
    async def embed_error(self, ctx, error):
        error = getattr(error, "original", error)
        if isinstance(error, discord.ext.commands.errors.MissingRequiredArgument) or isinstance(error, discord.ext.commands.errors.CommandInvokeError):

            embed = discord.Embed(
                title="Błąd",
                description="Nie podano(poprawnego) tytułu, opisu lub koloru\nPoprawne użycie `k!embed <tytuł>|<opis>|<kolor hex>`",
                color=discord.Colour.red()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Other(bot))