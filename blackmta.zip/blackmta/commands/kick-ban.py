from discord.ext import commands
import discord


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="kick", aliases=["k"])
    async def kick(self, ctx, member: discord.Member = None, *, reason=None):
        if not ctx.author.guild_permissions.kick_members:

            embed = discord.Embed(
                title="Błąd",
                description="Nie posiadasz uprawnień `Wyrzucanie członków`",
                color=discord.Colour.red()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)
        else:
            if member is None:

                embed = discord.Embed(
                    title="Błąd",
                    description="Nie podano użytkownika do wyrzucenia\nPoprawne użycie `k!kick <@użytkownik> [powód]`",
                    color=discord.Colour.red()
                )

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)
            else:
                if reason is None:
                    reason = f"Brak powodu"

                await member.kick(reason=reason + f" - Administrator {ctx.message.author}")

                embed = discord.Embed(
                    title="Pomyślnie wyrzucono użytkownika",
                    description=f"{ctx.author.mention} wyrzucił(-a) {member.mention} z powodu **{reason}**",
                    color=discord.Color.red()
                )

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)

    @commands.command(name="zajeb", aliases=["b"])
    async def ban(self, ctx, member: discord.Member = None, *, reason=None):
        if not ctx.author.guild_permissions.ban_members:

            embed = discord.Embed(
                title="Błąd",
                description="Nie posiadasz uprawnień `Banowanie członków`",
                color=discord.Colour.red()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)
        else:
            if member is None:

                embed = discord.Embed(
                    title="Błąd",
                    description="Nie podano użytkownika do zbanowania\nPoprawne użycie `k!ban <@użytkownik> [powód]`",
                    color=discord.Colour.red())

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)
            else:
                if reason is None:
                    reason = f"Brak powodu"
                await member.ban(reason=reason + f" - Administrator {ctx.message.author}")

                embed = discord.Embed(
                    title="Pomyślnie zbanowano użytkownika",
                    description=f"{ctx.author.mention} zbanował(-a) {member.mention} z powodu **{reason}**",
                    color=discord.Color.red()
                )

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)

    @commands.command(name="unban", aliases=["ub"])
    async def unban(self, ctx, user: discord.User = None):
        if not ctx.author.guild_permissions.ban_members:

            embed = discord.Embed(
                title="Błąd",
                description="Nie posiadasz uprawnień `Banowanie członków`",
                color=discord.Colour.red()
            )

            embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
            await ctx.reply(embed=embed)
        else:
            if user is None:

                embed = discord.Embed(
                    title="Błąd",
                    description="Nie podano użytkownika do odbanowania\nPoprawne użycie `k!unban <@użytkownik> [powód]`",
                    color=discord.Colour.red()
                )

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)
            else:
                await ctx.guild.unban(user=user)

                embed = discord.Embed(
                    title="Pomyślnie odbanowano użytkownika",
                    description=f"{ctx.author.mention} odbanował(-a) {user.mention}",
                    color=discord.Color.green()
                )

                embed.set_footer(text=f"{ctx.message.author.name} | {ctx.message.author.id}", icon_url=ctx.message.author.avatar_url)
                await ctx.reply(embed=embed)


def setup(bot):
    bot.add_cog(Admin(bot))