import discord 
from discord.ext import commands

client = commands.Bot(command_prefix= "!")

client.run("OTAxODA1Mjc0NjE5MzE0MTg2.YXVNnA.QPEcyH4ja3WzFTNb0hphpeQm4ZA")